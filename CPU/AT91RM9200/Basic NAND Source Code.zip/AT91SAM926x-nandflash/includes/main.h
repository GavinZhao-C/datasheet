 //  ----------------------------------------------------------------------------
 //          ATMEL Microcontroller Software Support  -  ROUSSET  -
 //  ----------------------------------------------------------------------------
 //  DISCLAIMER:  THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 //  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 //  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 //  DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 //  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 //  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 //  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 //  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 //  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 //  ----------------------------------------------------------------------------
#ifndef main_h
#define main_h

#ifdef AT91SAM9260
#include "AT91SAM9260.h"
#include "lib_AT91SAM9260.h"
#else
#include "AT91SAM9261.h"
#include "lib_AT91SAM9261.h"
#endif

#define TRUE	(1==1)
#define FALSE	(1==0)

#define AT91C_MASTER_CLOCK              99300000 
#define AT91C_BAUD_RATE                 115200

/*-------------------*/
/* TYPES DEFINITIONS */
/*-------------------*/
typedef unsigned char   u_char;
typedef unsigned short  u_short;
typedef unsigned int	u_int;

typedef unsigned int    uint;
typedef unsigned long	u_long;

typedef unsigned char   uint8_t;
typedef unsigned short  uint16_t;
typedef unsigned int    uint32_t;

typedef unsigned char	uchar;
typedef unsigned short	ushort;
typedef unsigned long	ulong;



// Global variables and functions definition
extern void AT91F_Configure_DBGU (unsigned int uClock);
extern void AT91F_DBGU_Printk(char *);
extern unsigned int AT91F_SetPLL(void);

#endif