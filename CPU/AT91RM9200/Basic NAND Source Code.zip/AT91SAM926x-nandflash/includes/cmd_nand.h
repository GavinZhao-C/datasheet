//*----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*----------------------------------------------------------------------------
/************************************************************************/
/*  sf_prim.h                                                           */
/*      declaration of serial flash primitive routines.                 */
/*                                                                      */
/*                                                                      */
/************************************************************************/

#define NANDFLASH_PAGESIZE 2048
#define AT91_SMARTMEDIA_BASE           0x40000000

#ifndef AT91SAM9261
#define AT91_SMART_MEDIA_ALE           (1 << 21)	/* our ALE is AD21 */
#define AT91_SMART_MEDIA_CLE           (1 << 22)	/* our CLE is AD22 */
#else
#define AT91_SMART_MEDIA_ALE           (1 << 22)	/* our ALE is AD22 */
#define AT91_SMART_MEDIA_CLE           (1 << 21)	/* our CLE is AD21 */
#endif

#ifdef AT91SAM9260
/* NANDFLASH is driven by NCS3 and use CE don't care capability */
#define NAND_DISABLE_CE
#define NAND_ENABLE_CE

#define NAND_WAIT_READY while (!(*AT91C_PIOC_PDSR & AT91C_PIO_PC13))

#endif

#ifdef AT91SAM9261
/* NANDFLASH is driven by PC14 PIO line */
#define NAND_DISABLE_CE do {*AT91C_PIOC_SODR = AT91C_PIO_PC14;} while(0)
#define NAND_ENABLE_CE 	do {*AT91C_PIOC_CODR = AT91C_PIO_PC14;} while(0)

#define NAND_WAIT_READY while (!(*AT91C_PIOC_PDSR & AT91C_PIO_PC15))

#endif

// 8 bits devices
#define WRITE_NAND_COMMAND(d, adr) do{ *(volatile unsigned char *)((unsigned long)adr | AT91_SMART_MEDIA_CLE) = (unsigned char)(d); } while(0)
#define WRITE_NAND_ADDRESS(d, adr) do{ *(volatile unsigned char *)((unsigned long)adr | AT91_SMART_MEDIA_ALE) = (unsigned char)(d); } while(0)
#define WRITE_NAND(d, adr) do{ *(volatile unsigned char *)((unsigned long)adr) = (unsigned char)d; } while(0)
#define READ_NAND(adr) ((volatile unsigned char)(*(volatile unsigned char *)(unsigned long)adr))

// 16 bits devices
#define WRITE_NAND16(d, adr) do{ *(volatile unsigned short *)((unsigned long)adr) = (unsigned short)d; } while(0)
#define READ_NAND16(adr) ((volatile unsigned short)(*(volatile unsigned short *)(unsigned long)adr))



/*
 * Standard NAND flash commands
 */
#define NAND_CMD_READ0			0
#define NAND_CMD_READ1			1
#define NAND_CMD_READ_CONFIRM	0x30
#define NAND_CMD_PAGEPROG		0x10
#define NAND_CMD_READOOB		0x50
#define NAND_CMD_ERASE1			0x60
#define NAND_CMD_STATUS			0x70
#define NAND_CMD_SEQIN			0x80
#define NAND_CMD_READID			0x90
#define NAND_CMD_ERASE2			0xd0
#define NAND_CMD_RESET			0xff

/*
 * NAND Flash Manufacturer ID Codes
 */
#define NAND_MFR_TOSHIBA	0x98
#define NAND_MFR_SAMSUNG	0xec
#define NAND_MFR_FUJITSU	0x04
#define NAND_MFR_NATIONAL	0x8f
#define NAND_MFR_RENESAS	0x07
#define NAND_MFR_STMICRO	0x20
#define NAND_MFR_MICRON		0x2c

#define NAND_BUSWIDTH_16	1

#define NAND_DATA	0
#define NAND_OOB	1

#define NAND_ECC_OFF	1
#define NAND_BAB_OFF	6
#define GOOD_BLOCK		0xff


/**
 * struct nand_flash_dev - NAND Flash Device ID Structure
 *
 * @id:   	device ID code
 * @pagesize:  	Pagesize in bytes. Either 256 or 512 or 0
 *		If the pagesize is 0, then the real pagesize
 *		and the eraseize are determined from the
 *		extended id bytes in the chip
 * @erasesize: 	Size of an erase block in the flash device.
 * @chipsize:  	Total chipsize in Mega Bytes
 */
struct nand_flash_dev {
	int id;
	unsigned long pagesize;
	unsigned long chipsize;
	unsigned long erasesize;
	unsigned long buswidth;
};

/**
 * struct nand_chip - NAND Flash Device ID Structure
 *
 * @chipsize:  	Chip size in bytes
 * @nand_bytes_per_page:  	Pagesize in bytes
 * @page_mask:  PageSize - 1
 * @blocksize:	Erase Block Size
 * @extended_address_s: 	TRUE	send extra address cycle
 * 							FALSE 	do not send extra address cycle
 * @nand_buswidth_16:  		TRUE	buswidth = 16 bits
 * 							FALSE 	buswidth = 8 bits
 * @nand_large_blocks: 		TRUE 	use large blocks functions
 * 							FALSE	use small blocks functions
 */
struct nand_info {
	unsigned long int chipsize;
	unsigned long int nand_bytes_per_page;
	unsigned long int page_mask;
	unsigned long int blocksize;
	char extended_address_s;
	char nand_buswidth_16;
	char nand_large_blocks;
};

extern struct nand_info nand_chip;
extern struct nand_flash_dev nand_flash_ids[];
extern int nand_manufacturers[];

typedef enum {
   SMC_UNKNOWN,
   SMC_KNOWN
} smc_chip_t;


extern void smc_read_data(unsigned long  file_pos,
                          unsigned char *buffer,
                          unsigned  int bytes_to_read);

extern void smc_write_data(unsigned long  file_pos,
                          unsigned char *buffer,
                          unsigned  int bytes_to_write);


extern smc_chip_t smc_chip_type(void);

