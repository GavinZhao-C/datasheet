 //  ----------------------------------------------------------------------------
 //          ATMEL Microcontroller Software Support  -  ROUSSET  -
 //  ----------------------------------------------------------------------------
 //  DISCLAIMER:  THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 //  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 //  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 //  DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 //  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 //  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 //  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 //  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 //  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 //  ----------------------------------------------------------------------------
//*----------------------------------------------------------------------------
//* File Name           : init.c
//* Object              : Low level initialisations written in C
//* Creation            : HIi   10/10/2003
//*
//*----------------------------------------------------------------------------
#include "main.h"


#define AT91C_PLLA_VALUE 	0x2060BF09// crystal= 18.432MHz
#define AT91C_SDRAM 		((volatile unsigned int *)0x20000000)

// The following functions must be written in ARM mode this function called directly
// by exception vector
extern void AT91F_Spurious_handler(void);
extern void AT91F_Default_IRQ_handler(void);
extern void AT91F_Default_FIQ_handler(void);
extern void IRQ_Handler_Entry(void);

//*----------------------------------------------------------------------------
//* \fn    AT91F_DBGU_Printk
//* \brief This function is used to send a string through the DBGU channel (Very low level debugging)
//*----------------------------------------------------------------------------
void AT91F_DBGU_Printk(
	char *buffer) // \arg pointer to a string ending by \0
{
	while(*buffer != '\0') {
		while (!AT91F_US_TxReady((AT91PS_USART)AT91C_BASE_DBGU));
		AT91F_US_PutChar((AT91PS_USART)AT91C_BASE_DBGU, *buffer++);
	}
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_Wait4KeyPressed
//* \brief 
//*----------------------------------------------------------------------------
unsigned int AT91F_Wait4KeyPressed(void) 
{
    while(!AT91F_US_RxReady((AT91PS_USART)AT91C_BASE_DBGU));
    return((int)AT91F_US_GetChar((AT91PS_USART)AT91C_BASE_DBGU));
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_DataAbort
//* \brief This function reports an Abort
//*----------------------------------------------------------------------------
void AT91F_SpuriousHandler() 
{
	AT91F_DBGU_Printk("-F- Spurious Interrupt detected\n\r");
	while (1);
}


//*----------------------------------------------------------------------------
//* \fn    AT91F_DataAbort
//* \brief This function reports an Abort
//*----------------------------------------------------------------------------
void AT91F_DataAbort() 
{
	AT91F_DBGU_Printk("-F- Data Abort detected\n\r");
	while (1);
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_FetchAbort
//* \brief This function reports an Abort
//*----------------------------------------------------------------------------
void AT91F_FetchAbort()
{
	AT91F_DBGU_Printk("-F- Prefetch Abort detected\n\r");
	while (1);
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_Undef
//* \brief This function reports an Abort
//*----------------------------------------------------------------------------
void AT91F_Undef() 
{
	AT91F_DBGU_Printk("-F- Undef detected\n\r");
	while (1);
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_UndefHandler
//* \brief This function reports that no handler have been set for current IT
//*----------------------------------------------------------------------------
void AT91F_UndefHandler() 
{
	AT91F_DBGU_Printk("-F- Undef detected\n\r");
	while (1);
}

//*--------------------------------------------------------------------------------------
//* Function Name       : AT91F_SetPLL
//* Object              : Set the PLLA to 200 and Master clock to 100 Mhz
//* Input Parameters    :
//* Output Parameters   :
//*--------------------------------------------------------------------------------------*/
unsigned int AT91F_SetPLL(void)
{
	AT91PS_PMC pPmc = AT91C_BASE_PMC;
	AT91PS_CKGR pCkgr = AT91C_BASE_CKGR;

	pPmc->PMC_IDR = 0xFFFFFFFF;

	/* -Setup the PLL A */
	pCkgr->CKGR_PLLAR = AT91C_PLLA_VALUE;

	while (!(*AT91C_PMC_SR & AT91C_PMC_LOCKA));
	
	/* - Switch Master Clock from PLLB to PLLA/2 */
	pPmc->PMC_MCKR = AT91C_PMC_CSS_PLLA_CLK | AT91C_PMC_PRES_CLK | AT91C_PMC_MDIV_2; 
	while (!(*AT91C_PMC_SR & AT91C_PMC_MCKRDY));

	return 1;	
}


//*--------------------------------------------------------------------------------------
//* \fn    AT91F_Configure_DBGU
//* \brief 
//*--------------------------------------------------------------------------------------
void AT91F_Configure_DBGU (unsigned int uClock)
{
	// Open PIO for DBGU
	AT91F_DBGU_CfgPIO();
	
	// Configure DBGU
	AT91F_US_Configure(
		(AT91PS_USART)AT91C_BASE_DBGU, // DBGU base address
		AT91C_MASTER_CLOCK,            			   // Master Clock
		AT91C_US_ASYNC_MODE,           // mode Register to be programmed
		115200,                        // baudrate to be programmed
		0                              // timeguard to be programmed
	);

	// Enable Transmitter
	AT91F_US_EnableTx((AT91PS_USART)AT91C_BASE_DBGU);
	// Enable Receiver
	AT91F_US_EnableRx((AT91PS_USART)AT91C_BASE_DBGU);
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_LowLevelInit
//* \brief This function performs very low level HW initialization
//*----------------------------------------------------------------------------
void AT91F_LowLevelInit(void)
{
#ifdef AT91SAM9260
	AT91PS_CCFG	pCcfg = AT91C_BASE_CCFG;
	pCcfg->CCFG_EBICSA |= 0x1003A;
#else /*AT91SAM9261*/
	AT91PS_MATRIX pMatrix = AT91C_BASE_MATRIX;
	pMatrix->MATRIX_EBICSA |= 0x1003A;
#endif	

	// Disable watchdog
	*(AT91C_WDTC_WDMR) = AT91C_WDTC_WDDIS;

	if (!AT91F_SetPLL())
		while(1);

	// Init Interrupt Controller
	AT91F_AIC_Open(
		AT91C_BASE_AIC,       	 // pointer to the AIC registers
		IRQ_Handler_Entry, 		 // IRQ exception vector
		AT91F_Default_FIQ_handler,  // \arg Default FIQ vector exception
		AT91F_Default_IRQ_handler, 	// \arg Default Handler set in ISR
		AT91F_Spurious_handler, 	// \arg Default Spurious Handler
		0);        					// Protect mode	AT91C_AIC_DCR_PROT

	// Perform 8 End Of Interrupt Command to make sure AIC will not Lock out nIRQ 
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);

	AT91F_AIC_SetExceptionVector((unsigned int *)0x0C, AT91F_FetchAbort);
	AT91F_AIC_SetExceptionVector((unsigned int *)0x10, AT91F_DataAbort);
	AT91F_AIC_SetExceptionVector((unsigned int *)0x4,  AT91F_Undef);
		
 	AT91F_Configure_DBGU (AT91C_MASTER_CLOCK);

}

