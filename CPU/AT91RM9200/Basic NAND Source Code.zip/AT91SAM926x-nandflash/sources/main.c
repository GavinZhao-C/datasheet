 //  ----------------------------------------------------------------------------
 //          ATMEL Microcontroller Software Support  -  ROUSSET  -
 //  ----------------------------------------------------------------------------
 //  DISCLAIMER:  THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 //  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 //  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 //  DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 //  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 //  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 //  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 //  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 //  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 //  ----------------------------------------------------------------------------

#include "main.h"
#include <stdio.h>
#include "com.h"
#include "cmd_nand.h"

// Methods defined in NandFlash.c
extern void AT91F_NandFlash_Init (void);
extern void AT91F_DBGU_Printk(	char *);

#ifdef CONFIG_NAND_ECC
extern void AT91F_ECC_Init(void);
extern unsigned short AT91F_Compute_ECC(void);
extern unsigned short AT91F_Check_ECC(unsigned short *);
#endif
char message[AT91C_CB_SIZE];



//*----------------------------------------------------------------------------
//* Function Name       : main
//* Object              : Main function
//* Input Parameters    : none
//* Output Parameters   : True
//*----------------------------------------------------------------------------*/
int main(void)
{
	u_char TestBuffer[2112], buffer[2112];
	unsigned int i;
#ifdef CONFIG_NAND_ECC
	int *ptr;
	unsigned short ecc, error_address[2],tmp,tmp_dat[2],tmp_data;
#endif

    // Reset Tx and Rx
	AT91F_US_ResetTx((AT91PS_USART) AT91C_BASE_DBGU);
	AT91F_US_ResetRx((AT91PS_USART) AT91C_BASE_DBGU);

	AT91F_DBGU_Printk("\n\n\r===================================\n\r");
	AT91F_DBGU_Printk("AT91SAM9260/9261 NandFlash example\n\r");
	AT91F_DBGU_Printk("==================================\n\r");
 
	//initialize 
	AT91F_NandFlash_Init();
#ifdef CONFIG_NAND_ECC
	AT91F_ECC_Init();
#endif
	buffer[0] = 0x12; /* to do not have a CRC eq to 0 */
	for (i = 1; i < 2112; i++){
		buffer[i] = i;
		TestBuffer[i] = 0x12;
	}

	//NAND READ SPARE AREA
	nand_read_page(0,TestBuffer,NAND_BAB_OFF,NAND_OOB);
	if(TestBuffer[NAND_BAB_OFF-1] != GOOD_BLOCK){
		AT91F_DBGU_Printk("-E- BAD BLOCK...\n\r");
		/* NEVER erase a bad block */
		while(1);
	}
	//NAND READ DATA
	nand_read_page(0,TestBuffer,NANDFLASH_PAGESIZE,NAND_DATA);
	
	//NAND ERASE IF NOT ERASED
	if(TestBuffer[0] != 0xff) AT91F_NandFlash_Erase_Block(0);

	//NAND READ DATA
	nand_read_page(0,TestBuffer,NANDFLASH_PAGESIZE,NAND_DATA);
	for (i = 0; i < NANDFLASH_PAGESIZE; i++){
		if (TestBuffer[i] != 0xff)
			/* not erased */
			while(1);
	}

	//NAND WRITE
	nand_write_page(0,buffer,NANDFLASH_PAGESIZE,NAND_DATA);

#ifdef CONFIG_NAND_ECC
	//NAND WRITE SPARE AREA
	tmp_dat[0] = *AT91C_HECC_PR;
	tmp_dat[1] = *AT91C_HECC_NPR;
	nand_write_page(0,tmp_dat,4,NAND_OOB);
	
#endif

	//NAND READ DATA
	nand_read_page(0,TestBuffer,NANDFLASH_PAGESIZE,NAND_DATA);

	for (i = 0; i < NANDFLASH_PAGESIZE; i++){
		if (buffer[i] != TestBuffer[i]) while(1);
	}
	AT91F_DBGU_Printk("No Data error\n\r");

#ifdef CONFIG_NAND_ECC
	ecc = AT91F_Check_ECC(&error_address[0]);
	
	switch(ecc){
		case 0:
		/* no error */
	        AT91F_DBGU_Printk("No ECC error\n\r");
			break;
		case AT91C_ECC_RECERR:
		/* recoverable error, word is error_address[0], bit is error_address[1] */
			tmp = error_address[0];
			buffer[tmp] = buffer[tmp] ^ error_address[1];
	        AT91F_DBGU_Printk("-E- ECC Error: Bit error recovered...\n\r");
			break;
		case AT91C_ECC_ECCERR:
		/* error on ECC value, the page should be forbidden */
	        AT91F_DBGU_Printk("-E- ECC Error: error on ECC value...\n\r");
	        
			break;
		case AT91C_ECC_MULERR:
	        AT91F_DBGU_Printk("-E- ECC Error: more than one bit is erroneous...\n\r");
			break;
		default:
			break;
	}

#endif
	


	while(1);


}