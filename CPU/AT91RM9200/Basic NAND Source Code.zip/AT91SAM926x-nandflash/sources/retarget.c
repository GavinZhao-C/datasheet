/*
** Copyright (C) ARM Limited, 2001. All rights reserved.
*/


/*
** This implements a 'retarget' layer for low-level IO.  Typically, this
** would contain your own target-dependent implementations of fputc(),
** ferror(), etc.
** 
** This example provides implementations of fputc(), ferror(),
** _sys_exit(), _ttywrch() and __user_initial_stackheap().
**
** Here, semihosting SWIs are used to display text onto the console 
** of the host debugger.  This mechanism is portable across ARMulator,
** Angel, Multi-ICE and EmbeddedICE.
**
** Alternatively, to output characters from the serial port of an 
** ARM Integrator Board (see serial.c), use:
**
**     #define USE_SERIAL_PORT
**
** or compile with 
**
**     -DUSE_SERIAL_PORT
*/


#include <stdio.h>
#include <rt_misc.h>

//#ifdef __thumb
/* Thumb Semihosting SWI */
//#define SemiSWI 0xAB
//#else
/* ARM Semihosting SWI */
//#define SemiSWI 0x123456
//#endif

//extern unsigned int bottom_of_heap;

/* Write a character */ 
/*__swi(SemiSWI) void _WriteC(unsigned op, char *c);
#define WriteC(c) _WriteC (0x3,c)
*/
/* Exit */
/*__swi(SemiSWI) void _Exit(unsigned op, unsigned except);
#define Exit() _Exit (0x18,0x20026)
*/

struct __FILE { int handle;   /* Add whatever you need here */};
/* FILE __stdout; */


extern void sendchar( char *ch );    // in serial.c

//extern int _ebss;
#if 0
int fputc(int ch, FILE *f)
{
    /* Place your implementation of fputc here     */
    /* e.g. write a character to a UART, or to the */
    /* debugger console with SWI WriteC            */
    char tempch = ch;

#ifdef USE_SERIAL_PORT
    sendchar( &tempch);
#else
    WriteC( &tempch );
#endif
    return ch;
}

int ferror(FILE *f)
{   /* Your implementation of ferror */
    return EOF;
}
#endif

/*
void _sys_exit(int return_code)
{
    Exit();         // for debugging

label:  goto label; // endless loop
}
*/

void _sys_exit(int return_code)
{
	return;
}


void _ttywrch(int ch)
{
/*    char tempch = ch;
#ifdef USE_SERIAL_PORT
    sendchar( &tempch );
#else
    WriteC( &tempch );
#endif
*/
}

#define HEAP_SIZE 	(32 *1024)

//*----------------------------------------------------------------------------
//* Function Name       : __user_initial_stackheap
//* Object              : Returns the locations of the initial stack and heap.
//* Input Parameters    :
//* Output Parameters   :The values returned in r0 to r3 depend on whether you
//*						are using the one or two region model:
//*			One region (r0,r1) is the single stack and heap region. r1 is
//*			greater than r0. r2 and r3 are ignored.
//*			Two regions (r0, r2) is the initial heap and (r3, r1) is the initial
//*			stack. r2 is greater than or equal to r0. r3 is less than r1.
//* Functions called    : none
//*----------------------------------------------------------------------------

__value_in_regs struct __initial_stackheap __user_initial_stackheap(
        unsigned R0, unsigned SP, unsigned R2, unsigned SL)
{
    struct __initial_stackheap config;

    config.heap_base = SP - HEAP_SIZE;
    config.stack_base = SP;

    return config;
}

