 //  ----------------------------------------------------------------------------
 //          ATMEL Microcontroller Software Support  -  ROUSSET  -
 //  ----------------------------------------------------------------------------
 //  DISCLAIMER:  THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 //  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 //  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 //  DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 //  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 //  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 //  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 //  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 //  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 //  ----------------------------------------------------------------------------
//*----------------------------------------------------------------------------
//* File Name           : NandFlash.c
//* Object              : NandFlash init for 9260 and 9261
//* Creation            : NLe   03/Aug/2005
//*----------------------------------------------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include "main.h"
#include "com.h"

//*----------------------------------------------------------------------------
//* \fn    AT91F_NandFlash_Init
//* \brief NandFlash init
//*----------------------------------------------------------------------------
void AT91F_NandFlash_Init (void)
{
	// Setup Smart Media, first enable the address range of CS3 in HMATRIX user interface
#ifdef AT91SAM9260
	AT91C_BASE_CCFG->CCFG_EBICSA |= AT91C_EBI_CS3A_SM;
#else /*AT91SAM9261*/
	AT91C_BASE_MATRIX->MATRIX_EBICSA |= AT91C_MATRIX_CS3A;
#endif		    
	// Configure SMC CS3
	AT91C_BASE_SMC->SMC_SETUP3 = 0;
		 
	AT91C_BASE_SMC->SMC_PULSE3 = 0x30003;
		 
	AT91C_BASE_SMC->SMC_CYCLE3 = 0x50005;
 
  	AT91C_BASE_SMC->SMC_CTRL3 = 0x2003;
 
 	AT91F_PIOC_CfgPMC ();
 
#ifdef AT91SAM9260
  	// Configure Ready/Busy signal
  	AT91F_PIO_CfgInput(AT91C_BASE_PIOC, AT91C_PIO_PC13);
 
  	// Enable NandFlash by periph
  	AT91F_PIO_CfgPeriph(AT91C_BASE_PIOC, AT91C_PC14_NCS3_NANDCS,0);
#else /*AT91SAM9261*/
 	// Configure Ready/Busy signal
  	AT91F_PIO_CfgInput(AT91C_BASE_PIOC, AT91C_PIO_PC15);
 
  	// Enable NandFlash
  	AT91F_PIO_CfgPeriph(AT91C_BASE_PIOC, (AT91C_PC0_SMOE |AT91C_PC1_SMWE), 0);
  	AT91F_PIO_CfgOutput(AT91C_BASE_PIOC, AT91C_PIO_PC14);
#endif
  	
 	if(!nand_chip_type())
 	{
    	sprintf(message, "\n\r-E- No NandFlash detected !!!\n\r");
    	AT91F_DBGU_Printk(message);
    }

}
