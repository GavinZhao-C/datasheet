//  ----------------------------------------------------------------------------
 //          ATMEL Microcontroller Software Support  -  ROUSSET  -
 //  ----------------------------------------------------------------------------
 //  DISCLAIMER:  THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 //  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 //  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 //  DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 //  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 //  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 //  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 //  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 //  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 //  ----------------------------------------------------------------------------
//*-------------------------------------------------------------------------
//* File Name           : ECC.c
//* Object              : ECC Controller management
//* Creation            : GGI   17/Jul/2006
//*-------------------------------------------------------------------------
#ifdef CONFIG_NAND_ECC

#include "AT91SAM9260.h"
#include "lib_AT91SAM9260.h"


void AT91F_ECC_Init(void){
	//reset
	*AT91C_HECC_CR = AT91C_ECC_RST;
  	// page size = 2112
  	*AT91C_HECC_MR = 2;
  	
}

//*----------------------------------------------------------------------------
//* \fn    AT91F_Check_ECC
//* \brief checks ECC status and returns bit error
//*----------------------------------------------------------------------------

unsigned short AT91F_Check_ECC(unsigned short *e_a){
	unsigned short ecc_status = *AT91C_HECC_SR;
	
	switch(ecc_status){
		case AT91C_ECC_RECERR:
			e_a[0] = *AT91C_HECC_PR & AT91C_ECC_WORDADDR;
			e_a[1] = *AT91C_HECC_PR & AT91C_ECC_BITADDR;
			break;
		case AT91C_ECC_ECCERR:
		case AT91C_ECC_MULERR:
			e_a[0] = 0;
			e_a[1] = 0;
			break;
		default:
			break;
	}
  	return ecc_status;
}



#endif