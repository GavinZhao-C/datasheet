For AT91SAM9260 devices (default)
------------------------------------
select AT91SAM9260 libv3
define AT91SAM9260 
INCLUDE AT91SAM9260.inc in cstartup_ads.s.
and define CONFIG_NAND_ECC.

For AT91SAM9261 devices 
------------------------------------
select AT91SAM9261 libv3
define AT91SAM9261 
and INCLUDE AT91SAM9261.inc in cstartup_ads.s. 

Note
------
This sample code is linked in SDRAM, this needs to be initialized first.
